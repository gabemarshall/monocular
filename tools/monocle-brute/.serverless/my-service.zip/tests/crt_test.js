const crt = require('./lib/crt')

crt('fmrcloud.com').then(function(blah){
	console.log(blah)
})